﻿namespace $safeprojectname$.SharePoint
{
    public interface ISharePointSettings
    {
        string UserName { get; }
        string Password { get; }
    }
}