﻿namespace $safeprojectname$.Core
{
    public class FileMasks
    {
        public const string ExcelFile = "Excel Files|*.xls";
    }
}