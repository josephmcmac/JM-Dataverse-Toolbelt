﻿namespace $safeprojectname$.Core
{
    public static class RegularExpressions
    {
        public const string IntegerOrEmpty = @"^[-]?\d*$";
    }
}