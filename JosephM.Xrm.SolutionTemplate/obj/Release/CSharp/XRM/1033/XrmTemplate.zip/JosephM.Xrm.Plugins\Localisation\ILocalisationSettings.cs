﻿namespace $safeprojectname$.Localisation
{
    public interface ILocalisationSettings
    {
        string TargetTimeZoneId { get; }
    }
}