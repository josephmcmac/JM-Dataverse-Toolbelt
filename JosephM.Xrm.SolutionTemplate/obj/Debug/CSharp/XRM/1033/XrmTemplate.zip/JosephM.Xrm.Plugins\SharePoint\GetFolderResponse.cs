﻿namespace $safeprojectname$.SharePoint
{
    public class GetFolderResponse
    {
        public string RelativeUrl { get; internal set; }
        public string QualifiedUrl { get; internal set; }
    }
}
