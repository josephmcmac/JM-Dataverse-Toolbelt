﻿namespace JosephM.Prism.Infrastructure.Constants
{
    public class MenuNames
    {
        public static string Crm
        {
            get { return "Crm"; }
        }

        public static string Test
        {
            get { return "Test"; }
        }

        public static string Settings
        {
            get { return "Settings"; }
        }
    }
}