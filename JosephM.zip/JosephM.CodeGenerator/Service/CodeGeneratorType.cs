﻿namespace JosephM.CodeGenerator.Service
{
    public enum CodeGeneratorType
    {
        CSharpMetadata,
        JavaScriptOptionSets,
        FetchToJavascript
    }
}