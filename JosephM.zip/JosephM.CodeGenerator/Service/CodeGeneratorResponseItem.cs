﻿using JosephM.Core.Service;

namespace JosephM.CodeGenerator.Service
{
    public class CodeGeneratorResponseItem : ServiceResponseItem
    {
    }
}