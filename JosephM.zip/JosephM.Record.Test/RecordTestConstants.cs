﻿namespace JosephM.Record.Test
{
    public static class RecordTestConstants
    {
        public static string ProjectPath
        {
            get { return "JosephM.Record.Test"; }
        }
    }
}