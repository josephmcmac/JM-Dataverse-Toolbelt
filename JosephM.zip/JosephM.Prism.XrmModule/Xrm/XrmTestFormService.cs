﻿#region

using JosephM.Application.ViewModel.RecordEntry.Metadata;

#endregion

namespace JosephM.Prism.XrmModule.Xrm
{
    public abstract class XrmFormService : FormServiceBase
    {
    }
}