﻿#region

using System.Reflection;
using System.Runtime.InteropServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("JosephM.Prism.XrmModule")]
[assembly: AssemblyCompany("JosephM")]
[assembly: AssemblyProduct("JosephM.Prism.XrmModule")]
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("1af04f1c-cb58-49bc-8487-d21bc34a60c4")]
[assembly: AssemblyVersion("1.2.*")]