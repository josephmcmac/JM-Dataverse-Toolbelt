﻿#region

using JosephM.Core.Service;

#endregion

namespace JosephM.Xrm.ImportExporter.Service
{
    public class XrmSolutionImporterExporterResponse : ServiceResponseBase<XrmSolutionImporterExporterResponseItem>
    {
    }
}