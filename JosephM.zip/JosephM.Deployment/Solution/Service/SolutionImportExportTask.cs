﻿namespace JosephM.Xrm.ImportExporter.Service
{
    public enum SolutionImportExportTask
    {
        ExportSolutions,
        ImportSolutions,
        MigrateSolutions
    }
}