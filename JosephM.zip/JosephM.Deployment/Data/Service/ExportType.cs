﻿namespace JosephM.Xrm.ImportExporter.Service
{
    public enum ExportType
    {
        AllRecords,
        SpecificRecords,
        FetchXml
    }
}