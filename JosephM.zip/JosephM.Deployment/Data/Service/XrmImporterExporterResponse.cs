﻿#region

using JosephM.Core.Service;

#endregion

namespace JosephM.Xrm.ImportExporter.Service
{
    public class XrmImporterExporterResponse : ServiceResponseBase<XrmImporterExporterResponseItem>
    {
    }
}