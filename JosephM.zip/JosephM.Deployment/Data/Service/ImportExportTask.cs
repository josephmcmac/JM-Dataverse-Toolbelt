﻿namespace JosephM.Xrm.ImportExporter.Service
{
    public enum ImportExportTask
    {
        ImportCsvs,
        ImportXml,
        ExportXml
    }
}