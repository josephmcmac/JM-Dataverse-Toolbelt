﻿namespace JosephM.Xrm.ImportExporter.Service
{
    public enum DateFormat
    {
        English,
        American
    }
}