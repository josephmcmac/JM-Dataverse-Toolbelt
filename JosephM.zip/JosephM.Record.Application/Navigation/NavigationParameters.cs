﻿namespace JosephM.Application.ViewModel.Navigation
{
    /// <summary>
    ///     Arguments To Pass In A
    /// </summary>
    public static class NavigationParameters
    {
        public const string RecordType = "RecordType";
        public const string RecordId = "RecordId";
        public const string RecordIdName = "RecordIdName";
    }
}