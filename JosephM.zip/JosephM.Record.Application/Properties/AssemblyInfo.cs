﻿#region

using System.Reflection;
using System.Runtime.InteropServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("JosephM.Application.ViewModel")]
[assembly: AssemblyCompany("JosephM")]
[assembly: AssemblyProduct("JosephM.Application.ViewModel")]
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("85cdb9f4-f772-47b2-9823-c19db190d2ae")]
[assembly: AssemblyVersion("1.2.*")]