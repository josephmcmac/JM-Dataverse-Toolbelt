﻿namespace JosephM.Application.ViewModel.RecordEntry.Metadata
{
    public class PersistentFormField : FormFieldMetadata
    {
        public PersistentFormField(string fieldName)
            : base(fieldName)
        {
        }
    }
}