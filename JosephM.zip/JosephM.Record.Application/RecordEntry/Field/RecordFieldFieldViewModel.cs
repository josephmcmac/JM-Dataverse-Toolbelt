﻿#region

using System.Linq;
using JosephM.Application.ViewModel.RecordEntry.Form;
using JosephM.Core.FieldType;
using JosephM.Record.Extentions;

#endregion

namespace JosephM.Application.ViewModel.RecordEntry.Field
{
    public class RecordFieldFieldViewModel : DropdownFieldViewModel<RecordField>
    {
        public RecordFieldFieldViewModel(string fieldName, string label, RecordEntryViewModelBase recordForm)
            : base(fieldName, label, recordForm)
        {
        }

        public override RecordField Value
        {
            get { return ValueObject as RecordField; }
            set
            {
                ValueObject = value;
                OnPropertyChanged("Value");
            }
        }
        private string _recordTypeForField;

        public string RecordTypeForField
        {
            get { return _recordTypeForField; }
            set
            {
                _recordTypeForField = value;
                var reference = GetRecordForm().ParentFormReference == null
                    ? _recordTypeForField
                    : _recordTypeForField + ":" + GetRecordForm().ParentFormReference;
                ItemsSource = GetRecordService()
                    .GetPicklistKeyValues (FieldName, GetRecordType(), reference, RecordEntryViewModel.GetRecord())
                    .Select(p => new RecordField(p.Key, p.Value));
            }
        }
    }
}