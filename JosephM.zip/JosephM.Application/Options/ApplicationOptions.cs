﻿using System;

namespace JosephM.Application.Options
{
    public class ApplicationOptions : IApplicationOptions
    {
        public void AddOption(string optionLabel, Action action, ApplicationOptionType type)
        {
        }
    }
}
