﻿namespace JosephM.Migration.Prism.Module.Connections
{
    public class MigrationExtentionBase
    {
        
    }
}