﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JosephM.Prism.TestModule.ObjectEncrypt
{
    public class TestClassToEncrypt
    {
        public string StringProperty { get; set; }
    }
}
