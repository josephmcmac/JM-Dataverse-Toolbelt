﻿using JosephM.Core.Service;

namespace JosephM.Prism.TestModule.Prism.TestDialog
{
    public class TestDialogResponse : ServiceResponseBase<TestDialogResponseItem>
    {
    }
}