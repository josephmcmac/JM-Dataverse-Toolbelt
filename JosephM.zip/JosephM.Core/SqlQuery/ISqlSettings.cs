﻿namespace JosephM.Core.Sql
{
    public interface ISqlSettings
    {
        string SqlServer { get; }
        string Database { get; }
    }
}