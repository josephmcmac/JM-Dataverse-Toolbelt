﻿using System.Runtime.Serialization;

namespace JosephM.Core.Service
{
    [DataContract]
    public abstract class ServiceRequestBase
    {
    }
}