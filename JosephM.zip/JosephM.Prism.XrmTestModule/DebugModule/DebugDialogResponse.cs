﻿using JosephM.Core.Service;

namespace JosephM.Prism.XrmTestModule.DebugModule
{
    public class DebugDialogResponse : ServiceResponseBase<DebugDialogResponseItem>
    {
    }
}