﻿namespace JosephM.Prism.XrmTestModule
{
    public class ThemedViewViewModel
    {
        public string Theme { get; set; }
    }
}