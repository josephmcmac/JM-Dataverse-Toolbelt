﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JosephM.Record.Test;

namespace JosephM.ObjectEncryption.Test
{
    public class TestObjectEncryptionModule : ObjectEncryptModule<ObjectEncryptDialog<TestClass>, TestClass>
    {

    }
}
