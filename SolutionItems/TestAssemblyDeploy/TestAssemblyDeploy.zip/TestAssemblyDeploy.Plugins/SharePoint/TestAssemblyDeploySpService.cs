﻿using System.Collections.Generic;
using TestAssemblyDeploy.Plugins.Xrm;

namespace TestAssemblyDeploy.Plugins.SharePoint
{
    public class TestAssemblyDeploySharepointService : SharePointService
    {
        public TestAssemblyDeploySharepointService(XrmService xrmService, ISharePointSettings sharepointSettings)
            : base(sharepointSettings, xrmService)
        {
        }

        public override IEnumerable<SharepointFolderConfig> SharepointFolderConfigs
        {
            get
            {

                return new SharepointFolderConfig[]
                {
                };
            }
        }
    }
}
