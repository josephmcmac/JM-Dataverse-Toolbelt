﻿using System;
using TestAssemblyDeploy.Plugins.Xrm;

namespace TestAssemblyDeploy.Plugins.SharePoint
{
    public class TestAssemblyDeploySharePointSettings : ISharePointSettings
    {
        public TestAssemblyDeploySharePointSettings(XrmService xrmService)
        {
            XrmService = xrmService;
        }

        private string _username;
        public string UserName
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        private string _password;
        public string Password
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        private XrmService XrmService { get; }
    }
}
