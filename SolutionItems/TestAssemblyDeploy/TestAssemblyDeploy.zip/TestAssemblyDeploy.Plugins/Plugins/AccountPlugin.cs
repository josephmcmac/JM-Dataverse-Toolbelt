﻿using Microsoft.Xrm.Sdk;

namespace TestAssemblyDeploy.Plugins.Plugins
{
    public class AccountPlugin : TestAssemblyDeployEntityPluginBase
    {
        public override void GoExtention()
        {
            throw new InvalidPluginExecutionException("TestingAssemblyDeploy");
        }
    }
}