﻿using TestAssemblyDeploy.Plugins.Services;
using TestAssemblyDeploy.Plugins.Rollups;
using TestAssemblyDeploy.Plugins.Xrm;
using TestAssemblyDeploy.Plugins.SharePoint;
using TestAssemblyDeploy.Plugins.Localisation;

namespace TestAssemblyDeploy.Plugins.Plugins
{
    /// <summary>
    /// class for shared services or settings objects for plugins
    /// </summary>
    public abstract class TestAssemblyDeployEntityPluginBase : XrmEntityPlugin
    {
        private TestAssemblyDeploySettings _settings;
        public TestAssemblyDeploySettings TestAssemblyDeploySettings
        {
            get
            {
                if (_settings == null)
                    _settings = new TestAssemblyDeploySettings(XrmService);
                return _settings;
            }
        }

        private TestAssemblyDeployService _service;
        public TestAssemblyDeployService TestAssemblyDeployService
        {
            get
            {
                if (_service == null)
                    _service = new TestAssemblyDeployService(XrmService, TestAssemblyDeploySettings);
                return _service;
            }
        }

        private TestAssemblyDeployRollupService _RollupService;
        public TestAssemblyDeployRollupService TestAssemblyDeployRollupService
        {
            get
            {
                if (_RollupService == null)
                    _RollupService = new TestAssemblyDeployRollupService(XrmService);
                return _RollupService;
            }
        }

        private TestAssemblyDeploySharepointService _sharePointService;
        public TestAssemblyDeploySharepointService TestAssemblyDeploySharepointService
        {
            get
            {
                if (_sharePointService == null)
                    _sharePointService = new TestAssemblyDeploySharepointService(XrmService, new TestAssemblyDeploySharePointSettings(XrmService));
                return _sharePointService;
            }
        }

        private LocalisationService _localisationService;
        public LocalisationService LocalisationService
        {
            get
            {
                if (_localisationService == null)
                    _localisationService = new LocalisationService(new LocalisationSettings());
                return _localisationService;
            }
        }
    }
}
