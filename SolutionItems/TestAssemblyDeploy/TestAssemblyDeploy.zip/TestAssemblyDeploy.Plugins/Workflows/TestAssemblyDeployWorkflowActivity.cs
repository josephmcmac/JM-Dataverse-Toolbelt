﻿using TestAssemblyDeploy.Plugins.Services;
using TestAssemblyDeploy.Plugins.Xrm;

namespace TestAssemblyDeploy.Plugins.Workflows
{
    /// <summary>
    /// class for shared services or settings objects for workflow activities
    /// </summary>
    public abstract class TestAssemblyDeployWorkflowActivity<T> : XrmWorkflowActivityInstance<T>
        where T : XrmWorkflowActivityRegistration
    {
        private TestAssemblyDeploySettings _settings;
        public TestAssemblyDeploySettings TestAssemblyDeploySettings
        {
            get
            {
                if (_settings == null)
                    _settings = new TestAssemblyDeploySettings(XrmService);
                return _settings;
            }
        }

        private TestAssemblyDeployService _service;
        public TestAssemblyDeployService TestAssemblyDeployService
        {
            get
            {
                if (_service == null)
                    _service = new TestAssemblyDeployService(XrmService, TestAssemblyDeploySettings);
                return _service;
            }
        }
    }
}
