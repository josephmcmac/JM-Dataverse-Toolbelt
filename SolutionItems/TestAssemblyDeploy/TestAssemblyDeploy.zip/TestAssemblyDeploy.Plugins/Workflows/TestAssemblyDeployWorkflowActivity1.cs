﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Schema;
using System.Activities;
using TestAssemblyDeploy.Plugins.Xrm;

namespace TestAssemblyDeploy.Plugins.Workflows
{
    /// <summary>
    /// This class is for the static type required for registration of the custom workflow activity in CRM
    /// </summary>
    public class TestAssemblyDeployWorkflowActivity1 : XrmWorkflowActivityRegistration
    {
        [Input("Input Argument 1")]
        [ReferenceTarget(Entities.account)]
        public InArgument<EntityReference> InputArgument1 { get; set; }

        [Input("Input Argument 2")]
        [ReferenceTarget(Entities.account)]
        public InArgument<EntityReference> InputArgument2 { get; set; }

        protected override XrmWorkflowActivityInstanceBase CreateInstance()
        {
            return new TestAssemblyDeployWorkflowActivity1Instance();
        }
    }

    /// <summary>
    /// This class is instantiated per execution
    /// </summary>
    public class TestAssemblyDeployWorkflowActivity1Instance
        : TestAssemblyDeployWorkflowActivity<TestAssemblyDeployWorkflowActivity1>
    {
        protected override void Execute()
        {
        }

    }
}
