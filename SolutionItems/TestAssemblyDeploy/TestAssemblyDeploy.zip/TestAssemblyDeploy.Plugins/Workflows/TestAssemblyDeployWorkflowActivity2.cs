﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;
using TestAssemblyDeploy.Plugins.Xrm;

namespace TestAssemblyDeploy.Plugins.Workflows
{
    /// <summary>
    /// This class is for the static type required for registration of the custom workflow activity in CRM
    /// </summary>
    public class TestAssemblyDeployWorkflowActivity2 : XrmWorkflowActivityRegistration
    {
        //[Input("Input Arg")]
        //[ReferenceTarget(Entities.account)]
        //public InArgument<EntityReference> InputArg { get; set; }

        //[Output("Output Arg")]
        //public OutArgument<bool> OutputArg { get; set; }

        protected override XrmWorkflowActivityInstanceBase CreateInstance()
        {
            return new TestAssemblyDeployWorkflowActivity2Instance();
        }
    }

    /// <summary>
    /// This class is instantiated per execution
    /// </summary>
    public class TestAssemblyDeployWorkflowActivity2Instance
        : TestAssemblyDeployWorkflowActivity<TestAssemblyDeployWorkflowActivity2>
    {
        protected override void Execute()
        {
        }
    }
}
