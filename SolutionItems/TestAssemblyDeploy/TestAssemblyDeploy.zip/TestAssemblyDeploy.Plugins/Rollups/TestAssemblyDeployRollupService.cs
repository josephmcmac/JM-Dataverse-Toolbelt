﻿using Microsoft.Xrm.Sdk;
using TestAssemblyDeploy.Plugins.Xrm;
using Schema;
using System;
using System.Collections.Generic;

namespace TestAssemblyDeploy.Plugins.Rollups
{
    public class TestAssemblyDeployRollupService : RollupService
    {
        public TestAssemblyDeployRollupService(XrmService xrmService)
            : base(xrmService)
        {
        }

        private IEnumerable<LookupRollup> _Rollups = new LookupRollup[]
        {
        };

        public override IEnumerable<LookupRollup> AllRollups => _Rollups;
    }
}