﻿using TestAssemblyDeploy.Plugins.Xrm;

namespace TestAssemblyDeploy.Plugins.Services
{
    /// <summary>
    /// A service class for performing logic
    /// </summary>
    public class TestAssemblyDeployService
    {
        private XrmService XrmService { get; set; }
        private TestAssemblyDeploySettings TestAssemblyDeploySettings { get; set; }

        public TestAssemblyDeployService(XrmService xrmService, TestAssemblyDeploySettings settings)
        {
            XrmService = xrmService;
            TestAssemblyDeploySettings = settings;
        }
    }
}
