﻿namespace TestAssemblyDeploy.Plugins.Localisation
{
    public class LocalisationSettings : ILocalisationSettings
    {
        //"AUS Eastern Standard Time";
        public string TargetTimeZoneId => throw new System.NotImplementedException();
    }
}
