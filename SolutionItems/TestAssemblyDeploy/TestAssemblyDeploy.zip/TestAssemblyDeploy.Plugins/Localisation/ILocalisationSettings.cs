﻿namespace TestAssemblyDeploy.Plugins.Localisation
{
    public interface ILocalisationSettings
    {
        string TargetTimeZoneId { get; }
    }
}