﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestAssemblyDeploy.Plugins.Test
{
    //this class just for general debug purposes
    [TestClass]
    public class DebugTests : TestAssemblyDeployXrmTest
    {
        [TestMethod]
        public void Debug()
        {
            var me = XrmService.WhoAmI();
        }
    }
}