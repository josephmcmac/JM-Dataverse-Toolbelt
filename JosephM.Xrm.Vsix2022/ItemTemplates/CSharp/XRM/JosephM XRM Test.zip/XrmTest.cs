﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    [TestClass]
    public class $safeitemname$ : $jmobjprefix$XrmTest
    {
        [TestMethod]
        public void $safeitemname$Test()
        {
        }
    }
}