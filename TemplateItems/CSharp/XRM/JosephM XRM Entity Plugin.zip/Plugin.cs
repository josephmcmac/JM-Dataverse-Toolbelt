﻿using $josephmrootnamespace$.Xrm;
using Schema;

namespace $rootnamespace$
{
    public class $safeitemname$ : $jmobjprefix$EntityPluginBase
    {
        public override void GoExtention()
        {
        }
    }
}